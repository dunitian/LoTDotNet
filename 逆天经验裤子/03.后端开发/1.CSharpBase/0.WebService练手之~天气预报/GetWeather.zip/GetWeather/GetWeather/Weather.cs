﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GetWeather
{
    public partial class Weather : Form
    {
        /// <summary>
        /// 实例化一个对象
        /// </summary>
        private DNT.MMD.WeatherWS ws = new DNT.MMD.WeatherWS();

        public Weather()
        {
            InitializeComponent();

            //获取返回的数组
            string[] WeatherInfo = ws.getWeather("", "");

            lbl_City.Text = WeatherInfo[1];
            lbl_kongqizhiliang.Text = WeatherInfo[5];
            lbl_shenghuotishi.Text = WeatherInfo[6];
            lbl_todayWeather.Text = WeatherInfo[4];
            lbl_UpdateDate.Text = WeatherInfo[3];

            label4.Text = WeatherInfo[7];
            label5.Text = WeatherInfo[8];
            label6.Text = WeatherInfo[9];
            pictureBox1.ImageLocation = "weather/" + WeatherInfo[10];
            pictureBox2.ImageLocation = "weather/" + WeatherInfo[11];

            label7.Text = WeatherInfo[12];
            label8.Text = WeatherInfo[13];
            label9.Text = WeatherInfo[14];
            pictureBox3.ImageLocation = "weather/" + WeatherInfo[15];
            pictureBox4.ImageLocation = "weather/" + WeatherInfo[16];

            label10.Text = WeatherInfo[17];
            label11.Text = WeatherInfo[18];
            label12.Text = WeatherInfo[19];
            pictureBox5.ImageLocation = "weather/" + WeatherInfo[20];
            pictureBox6.ImageLocation = "weather/" + WeatherInfo[21];

            label13.Text = WeatherInfo[22];
            label14.Text = WeatherInfo[23];
            label15.Text = WeatherInfo[24];
            pictureBox7.ImageLocation = "weather/" + WeatherInfo[25];
            pictureBox8.ImageLocation = "weather/" + WeatherInfo[26];

            label16.Text = WeatherInfo[27];
            label17.Text = WeatherInfo[28];
            label18.Text = WeatherInfo[29];
            pictureBox9.ImageLocation = "weather/" + WeatherInfo[30];
            pictureBox10.ImageLocation = "weather/" + WeatherInfo[31];
        }


    }
}
